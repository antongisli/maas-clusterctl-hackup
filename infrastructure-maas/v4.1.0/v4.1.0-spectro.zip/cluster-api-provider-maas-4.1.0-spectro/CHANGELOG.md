Version  v0.1.1
Tue Aug 10 05:40:00 UTC 2021

* Commit: Fix release path for MAAS; author: zulfilee
* Commit: Merge branch 'main' of https://github.com/spectrocloud/cluster-api-provider-maas into main; author: zulfilee
* Commit: dns record use uuid in domain name (#10); author: GitHub
* Commit: Merge branch 'main' of https://github.com/spectrocloud/cluster-api-provider-maas into main; author: zulfilee
* Commit: Release V0.1.0; author: zulfilee
